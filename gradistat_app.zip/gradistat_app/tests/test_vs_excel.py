"""Compara el motor Python amb els resultats de la macro original de GRADISTAT v9.1.

Els valors de referència (resultats_excel.json) s'han obtingut executant FolkAndWardMacro
de l'Excel original sobre les 20 mostres de casos.json.  Executa:  python -m pytest tests
"""
import json
import math
import pathlib
import sys

import pytest

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
from gradistat import CLASS_KEYS, analyse  # noqa: E402

CASES = json.loads((HERE / "casos.json").read_text())
EXCEL = json.loads((HERE / "resultats_excel.json").read_text())


def cells(res):
    """(fila, columna) del full 'Single Sample Statistics' -> valor calculat."""
    out = {}
    for k, (um, phi) in enumerate(res.modes[:3]):
        out[(8 + k, 2)], out[(8 + k, 4)] = um, phi
    for k, key in enumerate(["D10", "D50", "D90", "D90/D10", "D90-D10", "D75/D25", "D75-D25"]):
        out[(11 + k, 2)], out[(11 + k, 4)] = res.d_values[key]
    for k, v in enumerate([res.gravel, res.sand, res.mud]):
        out[(8 + k, 10)] = v / 100
    pos = [(12, 10), (13, 10), (14, 10), (15, 10), (16, 10), (17, 10)] + [(8 + k, 15) for k in range(10)]
    for key, rc in zip(CLASS_KEYS, pos):
        v = res.classes[key]
        out[rc] = v if v == "-" else v / 100
    for col, m in [(3, res.moments["arithmetic"]), (5, res.moments["geometric"]),
                   (7, res.moments["logarithmic"]), (8, res.folk_ward["geometric"]),
                   (11, res.folk_ward["logarithmic"])]:
        for k, key in enumerate(["mean", "sorting", "skewness", "kurtosis"]):
            out[(22 + k, col)] = m[key]
    return out


@pytest.mark.parametrize("i", range(len(CASES)))
def test_case(i):
    c, ref = CASES[i], EXCEL[i]
    res = analyse(c["ap"], c["w"], c.get("pan", 0), c.get("init"))
    assert ref.get("_txt_5,3") == res.sediment_name
    assert ref.get("_txt_4,13") == res.textural_group
    assert ref.get("_txt_4,3") == res.sample_type
    for (r, col), mine in cells(res).items():
        key = f"{r},{col}"
        if key not in ref:
            continue
        if mine == "-":
            assert ref["_txt_" + key] == "-"
        elif ref["_txt_" + key].startswith("#"):
            assert not math.isfinite(mine)
        else:
            assert math.isclose(ref[key], float(mine), rel_tol=1e-9, abs_tol=1e-9), key
